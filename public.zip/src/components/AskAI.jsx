import { useEffect, useRef, useState } from 'react';
import { Bot, Send, X } from 'lucide-react';

const suggestions = ['What does Didula do?', 'Show me the projects', 'How can I get in touch?'];

function answerFor(question) {
  const text = question.toLowerCase();
  if (/contact|email|reach|touch|hire|linkedin|github/.test(text)) return { text: 'You can find Didula’s contact details and social links in the About section.', href: '#about', label: 'View contact details' };
  if (/project|work|portfolio|build/.test(text)) return { text: 'Explore Didula’s selected software projects and their details in the Projects section.', href: '#projects', label: 'Explore projects' };
  if (/educat|degree|university|study/.test(text)) return { text: 'Didula earned a First Class BSc (Hons) in Computer Science from the University of Bedfordshire. The Education section has more.', href: '#education', label: 'View education' };
  if (/service|offer|skill|technology|tech|stack/.test(text)) return { text: 'Didula works across software engineering, AI, cloud, cybersecurity, and interface design.', href: '#services', label: 'Explore services' };
  if (/about|who|designer|coder|didula|do/.test(text)) return { text: 'Didula designs clear interfaces and builds secure, scalable software, with a focus on AI, cloud engineering, and modern web experiences.', href: '#about', label: 'Learn more' };
  return { text: 'I can help you find Didula’s projects, services, education, and contact details. Try asking about one of those topics.', href: null };
}

export default function AskAI() {
  const [open, setOpen] = useState(false);
  const [question, setQuestion] = useState('');
  const [messages, setMessages] = useState([]);
  const triggerRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    if (!open) return undefined;
    inputRef.current?.focus();
    const onKeyDown = event => {
      if (event.key === 'Escape') setOpen(false);
    };
    document.addEventListener('keydown', onKeyDown);
    return () => { document.removeEventListener('keydown', onKeyDown); triggerRef.current?.focus(); };
  }, [open]);

  const ask = value => {
    const trimmed = value.trim();
    if (!trimmed) return;
    setMessages(current => [...current, { question: trimmed, answer: answerFor(trimmed) }]);
    setQuestion('');
  };

  return <>
    <button ref={triggerRef} className="ask-ai-trigger" type="button" onClick={() => setOpen(true)} aria-label="Ask AI" aria-haspopup="dialog" aria-expanded={open} title="Ask AI">
      <Bot size={22} strokeWidth={1.8} aria-hidden="true" /><span>Ask AI</span>
    </button>
    {open && <div className="ask-ai-overlay" onPointerDown={event => { if (event.target === event.currentTarget) setOpen(false); }}>
      <section className="ask-ai-panel" role="dialog" aria-modal="true" aria-labelledby="ask-ai-title" aria-describedby="ask-ai-description">
        <div className="ask-ai-header"><div><h2 id="ask-ai-title">Ask AI</h2><p id="ask-ai-description">A quick guide to Didula’s portfolio.</p></div><button type="button" onClick={() => setOpen(false)} aria-label="Close Ask AI"><X size={19} /></button></div>
        <div className="ask-ai-conversation" aria-live="polite">
          <p className="ask-ai-intro">What would you like to know?</p>
          {messages.map((message, index) => <div className="ask-ai-exchange" key={index}><p className="ask-ai-question">{message.question}</p><div className="ask-ai-answer"><p>{message.answer.text}</p>{message.answer.href && <a href={message.answer.href} onClick={() => setOpen(false)}>{message.answer.label}</a>}</div></div>)}
        </div>
        {!messages.length && <div className="ask-ai-suggestions">{suggestions.map(item => <button key={item} type="button" onClick={() => ask(item)}>{item}</button>)}</div>}
        <form className="ask-ai-form" onSubmit={event => { event.preventDefault(); ask(question); }}><input ref={inputRef} value={question} onChange={event => setQuestion(event.target.value)} placeholder="Ask about the portfolio" aria-label="Ask about the portfolio" /><button type="submit" disabled={!question.trim()} aria-label="Send question"><Send size={18} /></button></form>
      </section>
    </div>}
  </>;
}
